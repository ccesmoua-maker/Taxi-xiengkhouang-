import 'package:flutter/material.dart';

void main() => runApp(const TaxiApp());

class TaxiApp extends StatelessWidget {
  const TaxiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'TAXI XIENGKHOUANG',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B45)), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final distance = TextEditingController(text: '1');
  String role = 'ລູກຄ້າ';
  int get fare {
    final km = double.tryParse(distance.text) ?? 0;
    return (km * 15000).round().clamp(15000, 1000000000);
  }
  int get fee => (fare * .15).round();
  String money(int n) => '${n.toString()} ກີບ';
  @override
  void dispose() { distance.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('TAXI XIENGKHOUANG'), centerTitle: true),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('ເດີນທາງປອດໄພ ໃນເມືອງແປກ', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        SizedBox(height: 8), Text('ພື້ນທີ່: ເມືອງແປກ, ແຂວງຊຽງຂວາງ'),
        SizedBox(height: 8), Text('ປະເພດລົດ: ລົດເກັງ'),
      ]))),
      const SizedBox(height: 12),
      const Text('ປະເພດຜູ້ໃຊ້', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'ລູກຄ້າ', label: Text('ລູກຄ້າ'), icon: Icon(Icons.person)),
          ButtonSegment(value: 'ຄົນຂັບ', label: Text('ຄົນຂັບ'), icon: Icon(Icons.drive_eta)),
          ButtonSegment(value: 'Admin', label: Text('Admin'), icon: Icon(Icons.admin_panel_settings)),
        ],
        selected: {role}, onSelectionChanged: (v) => setState(() => role = v.first),
      ),
      const SizedBox(height: 18),
      const Text('ຄຳນວນຄ່າໂດຍສານ', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      TextField(controller: distance, keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'ໄລຍະທາງ (km)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.route)),
        onChanged: (_) => setState(() {})),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('ຄ່າໂດຍສານໂດຍປະມານ'),
        Text(money(fare), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const Divider(),
        Text('ຄ່າທຳນຽມແພລດຟອມ 15%: ${money(fee)}'),
        Text('ລາຍຮັບຄົນຂັບ: ${money(fare-fee)}'),
      ]))),
      const SizedBox(height: 12),
      const Text('ວິທີຊຳລະ', style: TextStyle(fontWeight: FontWeight.bold)),
      const Wrap(spacing: 8, children: [
        Chip(avatar: Icon(Icons.payments), label: Text('ເງິນສົດ')),
        Chip(avatar: Icon(Icons.account_balance), label: Text('ໂອນເງິນ')),
      ]),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('ຕົວຢ່າງເທົ່ານັ້ນ'),
        content: Text('ບົດບາດ: $role\nຄ່າໂດຍສານ: ${money(fare)}\n\nການຈອງລົດຈິງຕ້ອງມີ backend, GPS ແລະແຜນທີ່.'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ປິດ'))],
      )), icon: const Icon(Icons.local_taxi), label: const Text('ທົດລອງເອີ້ນລົດ')),
      const SizedBox(height: 12),
      const Text('ໝາຍເຫດ: ນີ້ແມ່ນ UI ຕົວຢ່າງ; ຍັງບໍ່ມີ login, GPS, ການຈອງຈິງ ຫຼືການຢືນຢັນການໂອນ.', style: TextStyle(fontSize: 12)),
    ]),
  );
}
