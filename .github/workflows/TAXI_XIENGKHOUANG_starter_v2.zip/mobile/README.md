# Flutter Android starter

Install Flutter SDK and Android Studio. From this directory run:
1. `flutter create . --platforms=android` (creates the Android platform wrapper if missing)
2. `flutter pub get`
3. `flutter run`
4. `flutter build apk --debug`

This ZIP contains source files, not a compiled APK. Test and review before release.
