-- TAXI XIENGKHOUANG starter schema: PostgreSQL/Supabase-oriented
create extension if not exists pgcrypto;

do $$ begin create type public.app_role as enum ('customer','driver','admin');
exception when duplicate_object then null; end $$;
do $$ begin create type public.vehicle_type as enum ('sedan');
exception when duplicate_object then null; end $$;
do $$ begin create type public.trip_status as enum ('requested','accepted','driver_arrived','in_progress','completed','cancelled');
exception when duplicate_object then null; end $$;
do $$ begin create type public.payment_method as enum ('cash','bank_transfer');
exception when duplicate_object then null; end $$;
do $$ begin create type public.payment_status as enum ('pending','submitted','verified','rejected');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null, phone text unique,
 role public.app_role not null default 'customer',
 created_at timestamptz not null default now()
);
create table if not exists public.driver_profiles (
 user_id uuid primary key references public.profiles(id) on delete cascade,
 is_approved boolean not null default false,
 is_available boolean not null default false,
 license_number text,
 rating numeric(3,2) not null default 5 check (rating between 0 and 5),
 created_at timestamptz not null default now()
);
create table if not exists public.vehicles (
 id uuid primary key default gen_random_uuid(),
 driver_id uuid not null references public.driver_profiles(user_id) on delete cascade,
 vehicle_type public.vehicle_type not null default 'sedan',
 make text, model text, plate_number text not null unique, color text,
 is_active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.pricing_rules (
 id bigint generated always as identity primary key,
 area_name text not null default 'Pek District, Xieng Khouang, Laos',
 price_per_km_lak bigint not null default 15000 check (price_per_km_lak > 0),
 minimum_fare_lak bigint not null default 15000 check (minimum_fare_lak > 0),
 commission_percent numeric(5,2) not null default 15 check (commission_percent between 0 and 100),
 active boolean not null default true, updated_at timestamptz not null default now()
);
insert into public.pricing_rules(area_name,price_per_km_lak,minimum_fare_lak,commission_percent,active)
select 'Pek District, Xieng Khouang, Laos',15000,15000,15,true
where not exists(select 1 from public.pricing_rules where active=true);

create table if not exists public.trips (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid not null references public.profiles(id),
 driver_id uuid references public.driver_profiles(user_id),
 vehicle_id uuid references public.vehicles(id),
 status public.trip_status not null default 'requested',
 pickup_label text not null, pickup_lat double precision, pickup_lng double precision,
 dropoff_label text not null, dropoff_lat double precision, dropoff_lng double precision,
 distance_km numeric(8,2) not null check(distance_km >= 0),
 fare_lak bigint not null check(fare_lak >= 15000),
 platform_fee_lak bigint not null check(platform_fee_lak >= 0),
 driver_net_lak bigint not null check(driver_net_lak >= 0),
 payment_method public.payment_method not null,
 requested_at timestamptz not null default now(), accepted_at timestamptz,
 started_at timestamptz, completed_at timestamptz, cancelled_at timestamptz,
 created_at timestamptz not null default now()
);
create index if not exists trips_customer_created_idx on public.trips(customer_id,created_at desc);
create index if not exists trips_driver_status_idx on public.trips(driver_id,status);
create table if not exists public.driver_locations (
 driver_id uuid primary key references public.driver_profiles(user_id) on delete cascade,
 latitude double precision not null, longitude double precision not null,
 heading double precision, updated_at timestamptz not null default now()
);
create table if not exists public.payments (
 id uuid primary key default gen_random_uuid(),
 trip_id uuid not null unique references public.trips(id) on delete cascade,
 method public.payment_method not null, status public.payment_status not null default 'pending',
 amount_lak bigint not null check(amount_lak >= 0),
 transfer_reference text, proof_url text, submitted_at timestamptz,
 verified_at timestamptz, verified_by uuid references public.profiles(id),
 created_at timestamptz not null default now()
);
create table if not exists public.driver_earnings (
 id uuid primary key default gen_random_uuid(),
 trip_id uuid not null unique references public.trips(id) on delete cascade,
 driver_id uuid not null references public.driver_profiles(user_id),
 gross_fare_lak bigint not null, platform_fee_lak bigint not null, driver_net_lak bigint not null,
 platform_fee_settled boolean not null default false, created_at timestamptz not null default now()
);
create or replace function public.calculate_fare_lak(distance_km numeric)
returns bigint language sql immutable as $$
 select greatest(round(greatest(distance_km,0)*15000)::bigint,15000::bigint);
$$;
create or replace function public.calculate_platform_fee_lak(fare_lak bigint)
returns bigint language sql immutable as $$
 select round(greatest(fare_lak,0)*0.15)::bigint;
$$;
create or replace function public.calculate_driver_net_lak(fare_lak bigint)
returns bigint language sql immutable as $$
 select greatest(fare_lak,0)-public.calculate_platform_fee_lak(fare_lak);
$$;

-- Enable RLS. Policies below are minimal examples; production policies need review.
alter table public.profiles enable row level security;
alter table public.driver_profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.pricing_rules enable row level security;
alter table public.trips enable row level security;
alter table public.driver_locations enable row level security;
alter table public.payments enable row level security;
alter table public.driver_earnings enable row level security;
create policy "profile_select_own" on public.profiles for select using(auth.uid()=id);
create policy "profile_update_own" on public.profiles for update using(auth.uid()=id) with check(auth.uid()=id);
create policy "pricing_read_active" on public.pricing_rules for select using(active=true);
create policy "trip_read_participant" on public.trips for select using(auth.uid()=customer_id or auth.uid()=driver_id);

-- Intentionally no client-side write policies for trips/payments/driver approvals.
-- Implement server-side authorization, validated RPCs, and additional RLS before launch.
