# TAXI XIENGKHOUANG — Android starter

Confirmed: Android; Customer + Driver + Admin; Pek District, Xieng Khouang, Laos; sedan only; 15,000 LAK/km; minimum fare 15,000 LAK; platform commission 15%; cash and bank transfer.

Contents: `database/schema.sql`, `mobile/` Flutter starter, and `docs/architecture.md`.

This is a starter scaffold, not a production-ready app or compiled APK. Booking, authentication, GPS/maps, dispatch, notifications, admin workflows and bank-transfer verification still need implementation. Review security/RLS before production.
