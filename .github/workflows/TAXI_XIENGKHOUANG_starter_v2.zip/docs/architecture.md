# Architecture

Flutter Android client + PostgreSQL backend (e.g. Supabase). Roles: customer, driver, admin.

Fare = max(round(distance_km × 15,000), 15,000) LAK.
Platform fee = round(fare × 15%). Driver net = fare − platform fee.

Cash payment needs a controlled collection workflow. Bank transfers should remain unverified until backend/admin verification. Recalculate fare and validate trip status on the server; never trust client-submitted values.
