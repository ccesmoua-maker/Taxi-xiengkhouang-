# TAXI XIENGKHOUANG — Android starter with cloud APK build

Requirements configured:
- Android / Flutter
- Customer, Driver, Admin starter role selector
- Pek District, Xieng Khouang, Laos
- Sedan only
- Fare: 15,000 LAK/km; minimum 15,000 LAK
- Platform fee: 15%
- Payment options: cash and bank transfer

## Build APK using only an Android phone
This project includes `.github/workflows/android-apk.yml` for GitHub Actions.

1. Download and extract this ZIP if your phone has a file manager that can extract ZIP files.
2. Create/sign in to a GitHub account in your browser.
3. Create a new repository, for example `taxi-xiengkhouang`.
4. Upload the extracted project files and folders to the repository root. Make sure `.github/workflows/android-apk.yml` is included. If GitHub's mobile web interface does not let you upload a whole folder, use GitHub's browser-based Codespaces/terminal or another Git upload method.
5. In the repository, open **Actions**, choose **Build TAXI XIENGKHOUANG Android APK**, and tap **Run workflow** (or push to `main`).
6. When the workflow succeeds, open the run and download the artifact named `TAXI-XIENGKHOUANG-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.
7. Install the APK on your Android phone. You may need to allow installation from your browser/files app.

## Limitations
- The workflow produces a debug APK for testing, not a release-signed APK for public distribution.
- The starter UI is a demo; live booking, login, maps/GPS, dispatch, notifications, admin workflows, and verified bank-transfer processing are not implemented yet.
- The SQL schema is a starting point; production security policies and server-side validation must be completed before real use.
